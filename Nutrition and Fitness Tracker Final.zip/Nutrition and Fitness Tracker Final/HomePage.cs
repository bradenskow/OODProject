﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nutrition.NutritionTracker
{
    public class HomePage
    {
        public float TodayCalories
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayProtein
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayCarbs
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayFat
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminD
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayZinc
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayIron
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayMagnesium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayFolate
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayCalcium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminC
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminE
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayIodine
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodaySelenium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayPotassium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayBiotin
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayCopper
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminB12
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayManganese
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayChromium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminA
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminK
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminB6
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminB2
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminB1
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayVitaminB3
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodayFluoride
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodaySodium
        {
            get
            {
                throw new NotImplementedException();
            }

        }

        public float TodaySugar
        {
            get
            {
                throw new NotImplementedException();
            }

        }


    }
}