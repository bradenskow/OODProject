﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApplication
{
    public class Exercise
    {
        public string Type { get; private set; }
        public string ExerciseName { get; private set; }
        private int repetitions;
        private int sets;
        private int weight;

        public Exercise(string type, string name, int repetitions, int sets, int weight)
        {
            Type = type;
            ExerciseName = name;
            this.repetitions = repetitions;
            this.sets = sets;
            this.weight = weight;
        }
        public int Repetitions
        {
            get { return repetitions; }
            set { if (value > 0) repetitions = value; }
        }

        public int Sets
        {
            get { return sets; }
            set { if (value > 0) sets = value; }
        }

        public int Weight
        {
            get { return weight; }
            set { if (value >= 0) weight = value; }
        }

        public void UpdateReps(int newReps)
        {
            if (newReps > 0)
            {
                repetitions = newReps;
            }
        }
    }

}

