﻿namespace FitnessApplication
{
    partial class FitnessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartWorkoutBtn = new System.Windows.Forms.Button();
            this.listViewWorkoutLog = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.LabelWorkoutLog = new System.Windows.Forms.Label();
            this.refreshBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StartWorkoutBtn
            // 
            this.StartWorkoutBtn.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.StartWorkoutBtn.Location = new System.Drawing.Point(136, 57);
            this.StartWorkoutBtn.Name = "StartWorkoutBtn";
            this.StartWorkoutBtn.Size = new System.Drawing.Size(205, 80);
            this.StartWorkoutBtn.TabIndex = 0;
            this.StartWorkoutBtn.Text = "Start Workout";
            this.StartWorkoutBtn.UseVisualStyleBackColor = false;
            this.StartWorkoutBtn.Click += new System.EventHandler(this.StartWorkoutBtn_Click);
            // 
            // listViewWorkoutLog
            // 
            this.listViewWorkoutLog.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.listViewWorkoutLog.FullRowSelect = true;
            this.listViewWorkoutLog.HideSelection = false;
            this.listViewWorkoutLog.Location = new System.Drawing.Point(21, 222);
            this.listViewWorkoutLog.Name = "listViewWorkoutLog";
            this.listViewWorkoutLog.Size = new System.Drawing.Size(458, 362);
            this.listViewWorkoutLog.TabIndex = 1;
            this.listViewWorkoutLog.UseCompatibleStateImageBehavior = false;
            this.listViewWorkoutLog.View = System.Windows.Forms.View.Details;
            this.listViewWorkoutLog.SelectedIndexChanged += new System.EventHandler(this.listViewWorkoutLog_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Workout Name";
            this.columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Duration";
            this.columnHeader2.Width = 70;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Intensity Level";
            this.columnHeader3.Width = 100;
            // 
            // LabelWorkoutLog
            // 
            this.LabelWorkoutLog.AutoSize = true;
            this.LabelWorkoutLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelWorkoutLog.Location = new System.Drawing.Point(129, 167);
            this.LabelWorkoutLog.Name = "LabelWorkoutLog";
            this.LabelWorkoutLog.Size = new System.Drawing.Size(221, 40);
            this.LabelWorkoutLog.TabIndex = 3;
            this.LabelWorkoutLog.Text = "Workout Log";
            this.LabelWorkoutLog.Click += new System.EventHandler(this.LabelWorkoutLog_Click);
            // 
            // refreshBtn
            // 
            this.refreshBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshBtn.Location = new System.Drawing.Point(380, 172);
            this.refreshBtn.Name = "refreshBtn";
            this.refreshBtn.Size = new System.Drawing.Size(43, 39);
            this.refreshBtn.TabIndex = 4;
            this.refreshBtn.Text = "↻";
            this.refreshBtn.UseVisualStyleBackColor = true;
            this.refreshBtn.Click += new System.EventHandler(this.refreshBtn_Click);
            // 
            // FitnessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 603);
            this.Controls.Add(this.refreshBtn);
            this.Controls.Add(this.LabelWorkoutLog);
            this.Controls.Add(this.listViewWorkoutLog);
            this.Controls.Add(this.StartWorkoutBtn);
            this.Name = "FitnessForm";
            this.Text = "FitnessForm";
            this.Load += new System.EventHandler(this.FitnessForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartWorkoutBtn;
        private System.Windows.Forms.ListView listViewWorkoutLog;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label LabelWorkoutLog;
        private System.Windows.Forms.Button refreshBtn;
    }
}