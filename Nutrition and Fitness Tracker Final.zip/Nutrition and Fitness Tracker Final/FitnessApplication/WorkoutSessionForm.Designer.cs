﻿namespace FitnessApplication
{
    partial class WorkoutSessionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.WorkoutTimer = new System.Windows.Forms.Timer(this.components);
            this.labelTimer = new System.Windows.Forms.Label();
            this.LabelWorkoutName = new System.Windows.Forms.Label();
            this.FinishWorkoutBtn = new System.Windows.Forms.Button();
            this.AddExerciseBtn = new System.Windows.Forms.Button();
            this.CancelWorkoutBtn = new System.Windows.Forms.Button();
            this.listViewExercises = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.comboBoxIntensity = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // WorkoutTimer
            // 
            this.WorkoutTimer.Interval = 1000;
            this.WorkoutTimer.Tick += new System.EventHandler(this.WorkoutTimer_Tick);
            // 
            // labelTimer
            // 
            this.labelTimer.AutoSize = true;
            this.labelTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTimer.Location = new System.Drawing.Point(25, 79);
            this.labelTimer.Name = "labelTimer";
            this.labelTimer.Size = new System.Drawing.Size(110, 32);
            this.labelTimer.TabIndex = 0;
            this.labelTimer.Text = "0:00:00";
            // 
            // LabelWorkoutName
            // 
            this.LabelWorkoutName.AutoSize = true;
            this.LabelWorkoutName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LabelWorkoutName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelWorkoutName.Location = new System.Drawing.Point(23, 20);
            this.LabelWorkoutName.Name = "LabelWorkoutName";
            this.LabelWorkoutName.Size = new System.Drawing.Size(177, 46);
            this.LabelWorkoutName.TabIndex = 1;
            this.LabelWorkoutName.Text = "Workout";
            this.LabelWorkoutName.Click += new System.EventHandler(this.LabelWorkoutName_Click);
            // 
            // FinishWorkoutBtn
            // 
            this.FinishWorkoutBtn.BackColor = System.Drawing.Color.LightGreen;
            this.FinishWorkoutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FinishWorkoutBtn.Location = new System.Drawing.Point(487, 20);
            this.FinishWorkoutBtn.Name = "FinishWorkoutBtn";
            this.FinishWorkoutBtn.Size = new System.Drawing.Size(193, 53);
            this.FinishWorkoutBtn.TabIndex = 2;
            this.FinishWorkoutBtn.Text = "Finish Workout";
            this.FinishWorkoutBtn.UseVisualStyleBackColor = false;
            this.FinishWorkoutBtn.Click += new System.EventHandler(this.FinishWorkoutBtn_Click);
            // 
            // AddExerciseBtn
            // 
            this.AddExerciseBtn.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.AddExerciseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddExerciseBtn.Location = new System.Drawing.Point(20, 230);
            this.AddExerciseBtn.Name = "AddExerciseBtn";
            this.AddExerciseBtn.Size = new System.Drawing.Size(658, 55);
            this.AddExerciseBtn.TabIndex = 3;
            this.AddExerciseBtn.Text = "Add Exercise";
            this.AddExerciseBtn.UseVisualStyleBackColor = false;
            this.AddExerciseBtn.Click += new System.EventHandler(this.GetExerciseForm_Click);
            // 
            // CancelWorkoutBtn
            // 
            this.CancelWorkoutBtn.BackColor = System.Drawing.Color.Salmon;
            this.CancelWorkoutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelWorkoutBtn.Location = new System.Drawing.Point(22, 810);
            this.CancelWorkoutBtn.Name = "CancelWorkoutBtn";
            this.CancelWorkoutBtn.Size = new System.Drawing.Size(658, 51);
            this.CancelWorkoutBtn.TabIndex = 4;
            this.CancelWorkoutBtn.Text = "Cancel Workout";
            this.CancelWorkoutBtn.UseVisualStyleBackColor = false;
            this.CancelWorkoutBtn.Click += new System.EventHandler(this.CancelWorkoutBtn_Click);
            // 
            // listViewExercises
            // 
            this.listViewExercises.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listViewExercises.FullRowSelect = true;
            this.listViewExercises.HideSelection = false;
            this.listViewExercises.Location = new System.Drawing.Point(22, 304);
            this.listViewExercises.Name = "listViewExercises";
            this.listViewExercises.Size = new System.Drawing.Size(658, 484);
            this.listViewExercises.TabIndex = 5;
            this.listViewExercises.UseCompatibleStateImageBehavior = false;
            this.listViewExercises.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Exercise Type";
            this.columnHeader1.Width = 115;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Exercise Name";
            this.columnHeader2.Width = 170;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Reps";
            this.columnHeader3.Width = 50;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Sets";
            this.columnHeader4.Width = 50;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Weight";
            this.columnHeader5.Width = 50;
            // 
            // comboBoxIntensity
            // 
            this.comboBoxIntensity.AutoCompleteCustomSource.AddRange(new string[] {
            "High",
            "Medium",
            "Low"});
            this.comboBoxIntensity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxIntensity.FormattingEnabled = true;
            this.comboBoxIntensity.Location = new System.Drawing.Point(487, 174);
            this.comboBoxIntensity.Name = "comboBoxIntensity";
            this.comboBoxIntensity.Size = new System.Drawing.Size(191, 37);
            this.comboBoxIntensity.TabIndex = 8;
            this.comboBoxIntensity.SelectedIndexChanged += new System.EventHandler(this.comboBoxIntensity_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(542, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Intensity Level";
            // 
            // WorkoutSessionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 883);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxIntensity);
            this.Controls.Add(this.listViewExercises);
            this.Controls.Add(this.CancelWorkoutBtn);
            this.Controls.Add(this.AddExerciseBtn);
            this.Controls.Add(this.FinishWorkoutBtn);
            this.Controls.Add(this.LabelWorkoutName);
            this.Controls.Add(this.labelTimer);
            this.Name = "WorkoutSessionForm";
            this.Text = "WorkoutSessionForm";
            this.Load += new System.EventHandler(this.WorkoutSessionForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer WorkoutTimer;
        private System.Windows.Forms.Label labelTimer;
        private System.Windows.Forms.Label LabelWorkoutName;
        private System.Windows.Forms.Button FinishWorkoutBtn;
        private System.Windows.Forms.Button AddExerciseBtn;
        private System.Windows.Forms.Button CancelWorkoutBtn;
        private System.Windows.Forms.ListView listViewExercises;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ComboBox comboBoxIntensity;
        private System.Windows.Forms.Label label1;
    }
}