﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApplication
{
    public class User
    {
        string Name;
        int age;
        double height;
        double weight;
        int Level;

        
    }
}
