﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public partial class FitnessForm : Form
    {
        private WorkoutLog workoutLog;
        public FitnessForm()
        {
            InitializeComponent();
            workoutLog = WorkoutLog.GetInstance();
            UpdateWorkoutLogDisplay();
        }

        private void UpdateWorkoutLogDisplay()
        {
            listViewWorkoutLog.Items.Clear();
            foreach (var workout in WorkoutLog.GetInstance().Workouts)
            {
                var item = new ListViewItem(new string[]
                {
                    workout.WorkoutName,
                    workout.GetFormattedDuration(),
                    workout.IntensityLevel.ToString()
                });
                listViewWorkoutLog.Items.Add(item);
            }
        }
        private void StartWorkoutBtn_Click(object sender, EventArgs e)
        {
            WorkoutSessionForm workoutSession = new WorkoutSessionForm();

            workoutSession.Show();
        }

        private void FitnessForm_Load(object sender, EventArgs e)
        {
            UpdateWorkoutLogDisplay();
        }

        private void LabelWorkoutLog_Click(object sender, EventArgs e)
        {

        }

        private void listViewWorkoutLog_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            UpdateWorkoutLogDisplay();
        }
    }
}
