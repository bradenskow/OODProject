﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApplication
{
    public class WorkoutLog
    {
        private static WorkoutLog instance;
        private List<Workout> workouts = new List<Workout>();

        private WorkoutLog() { }

        public static WorkoutLog GetInstance()
        {
            if (instance == null)
            {
                instance = new WorkoutLog();
            }
            return instance;
        }

        public void AddWorkout(Workout workout)
        {
            workouts.Add(workout);
        }

        public IEnumerable<Workout> Workouts
        {
            get { return workouts.AsReadOnly(); }
        }
    }

}
