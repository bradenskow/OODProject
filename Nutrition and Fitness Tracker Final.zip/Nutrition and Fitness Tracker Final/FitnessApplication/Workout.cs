﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FitnessApplication
{
    public class Workout
    {
        public string WorkoutName { get; set; }
        private int duration;
        public Intensity IntensityLevel { get; set; }
        private List<string> notes = new List<string>();
        private List<Exercise> exercises = new List<Exercise>();
        private int timerSeconds;

        public Workout(string name, Intensity intensity)
        {
            WorkoutName = name;
            IntensityLevel = intensity;
        }

        public IEnumerable<Exercise> Exercises
        {
            get { return exercises.AsReadOnly(); }
        }

        public IEnumerable<string> Notes
        {
            get { return notes.AsReadOnly(); }
        }

        public int Duration
        {
            get { return duration; }
            private set { duration = value; }
        }

        public void AddExercise(Exercise exercise)
        {
            exercises.Add(exercise);
        }

        public void UpdateTimer()
        {
            timerSeconds++;
            Duration = timerSeconds / 60;
        }

        public string GetFormattedDuration()
        {
            return TimeSpan.FromSeconds(timerSeconds).ToString(@"hh\:mm\:ss");
        }

        public void FinishWorkout()
        {
            Duration = timerSeconds;
        }
    }

}
