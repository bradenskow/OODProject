﻿using Microsoft.VisualBasic;
using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public partial class WorkoutSessionForm : Form
    {
        private Workout currentWorkout;
        private Timer workoutTimer;


        public WorkoutSessionForm()
        {
            InitializeComponent();
            currentWorkout = new Workout("Default Workout", Intensity.Medium);
            workoutTimer = new Timer();
            workoutTimer.Interval = 1000;
            workoutTimer.Tick += WorkoutTimer_Tick;
            workoutTimer.Start();
        }

        private void WorkoutTimer_Tick(object sender, EventArgs e)
        {
                currentWorkout.UpdateTimer();
                labelTimer.Text = currentWorkout.GetFormattedDuration();

        }

        private void LabelWorkoutName_Click(object sender, EventArgs e)
        {
            try
            {
                string input = Interaction.InputBox("Enter new workout name:", "Workout Name", LabelWorkoutName.Text);
                if (!string.IsNullOrEmpty(input))
                {
                    currentWorkout.WorkoutName = input;
                    LabelWorkoutName.Text = input;
                }
            }
            catch (Exception x)
            {
                MessageBox.Show("An error occurred: " + x.Message);
            }
        }

        private void FinishWorkoutBtn_Click(object sender, EventArgs e)
        {
            if (comboBoxIntensity.SelectedItem != null)
            {
                currentWorkout.IntensityLevel = (Intensity)comboBoxIntensity.SelectedItem;
                currentWorkout.FinishWorkout();
                WorkoutLog.GetInstance().AddWorkout(currentWorkout);

                MessageBox.Show("Workout completed and logged!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select an intensity level.");
            }
        }

        private void GetExerciseForm_Click(object sender, EventArgs e)
        {
            using ( var addExerciseForm = new AddExerciseForm())
            {
                if (addExerciseForm.ShowDialog() == DialogResult.OK)
                {
                    currentWorkout.AddExercise(addExerciseForm.NewExercise);
                    UpdateExerciseListUI();
                }
            }
        }

        private void UpdateExerciseListUI()
        {
            listViewExercises.Items.Clear(); 
            foreach (var exercise in currentWorkout.Exercises)
            {
                ListViewItem item = new ListViewItem(new[] {
                exercise.Type,
                exercise.ExerciseName,
                exercise.Repetitions.ToString(),
                exercise.Sets.ToString(),
                exercise.Weight.ToString()
                });
                listViewExercises.Items.Add(item);
            }
        }
        private void CancelWorkoutBtn_Click(object sender, EventArgs e)
        {
            var confirmResult = MessageBox.Show("Are you sure you want to cancel the workout?",
                                        "Confirm Cancel",
                                        MessageBoxButtons.YesNo,
                                        MessageBoxIcon.Question);

            if (confirmResult == DialogResult.Yes)
            {
                workoutTimer.Stop();
                currentWorkout = null;

                labelTimer.Text = "00:00:00";

                this.Close(); 
            }
        }

        private void WorkoutSessionForm_Load(object sender, EventArgs e)
        {
            comboBoxIntensity.DataSource = Enum.GetValues(typeof(Intensity));
        }

        private void comboBoxIntensity_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}
