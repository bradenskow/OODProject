﻿using NutritionTracker;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitnessApplication
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnFitness_Click(object sender, EventArgs e)
        {
            FitnessForm fitnessForm = new FitnessForm();

            fitnessForm.Show();
        }

        private void NutritionBtn_Click(object sender, EventArgs e)
        {
            HomeScreen fitnessForm = new HomeScreen();

            fitnessForm.Show();
        }
    }
}
