﻿namespace FitnessApplication
{
    partial class AddExerciseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxExerciseType = new System.Windows.Forms.TextBox();
            this.txtBoxExerciseName = new System.Windows.Forms.TextBox();
            this.txtBoxSets = new System.Windows.Forms.TextBox();
            this.txtBoxReps = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBoxWeight = new System.Windows.Forms.TextBox();
            this.AddExerciseBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBoxExerciseType
            // 
            this.txtBoxExerciseType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxExerciseType.Location = new System.Drawing.Point(198, 28);
            this.txtBoxExerciseType.Name = "txtBoxExerciseType";
            this.txtBoxExerciseType.Size = new System.Drawing.Size(206, 35);
            this.txtBoxExerciseType.TabIndex = 0;
            // 
            // txtBoxExerciseName
            // 
            this.txtBoxExerciseName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxExerciseName.Location = new System.Drawing.Point(198, 82);
            this.txtBoxExerciseName.Name = "txtBoxExerciseName";
            this.txtBoxExerciseName.Size = new System.Drawing.Size(206, 35);
            this.txtBoxExerciseName.TabIndex = 1;
            // 
            // txtBoxSets
            // 
            this.txtBoxSets.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSets.Location = new System.Drawing.Point(198, 194);
            this.txtBoxSets.Name = "txtBoxSets";
            this.txtBoxSets.Size = new System.Drawing.Size(129, 35);
            this.txtBoxSets.TabIndex = 2;
            // 
            // txtBoxReps
            // 
            this.txtBoxReps.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxReps.Location = new System.Drawing.Point(198, 144);
            this.txtBoxReps.Name = "txtBoxReps";
            this.txtBoxReps.Size = new System.Drawing.Size(129, 35);
            this.txtBoxReps.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Exercise Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reps";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Sets";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 29);
            this.label4.TabIndex = 7;
            this.label4.Text = "Exercise Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 248);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 29);
            this.label5.TabIndex = 8;
            this.label5.Text = "Weight";
            // 
            // txtBoxWeight
            // 
            this.txtBoxWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxWeight.Location = new System.Drawing.Point(198, 248);
            this.txtBoxWeight.Name = "txtBoxWeight";
            this.txtBoxWeight.Size = new System.Drawing.Size(129, 35);
            this.txtBoxWeight.TabIndex = 9;
            // 
            // AddExerciseBtn
            // 
            this.AddExerciseBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.AddExerciseBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddExerciseBtn.Location = new System.Drawing.Point(12, 336);
            this.AddExerciseBtn.Name = "AddExerciseBtn";
            this.AddExerciseBtn.Size = new System.Drawing.Size(167, 50);
            this.AddExerciseBtn.TabIndex = 10;
            this.AddExerciseBtn.Text = "Add Exercise";
            this.AddExerciseBtn.UseVisualStyleBackColor = false;
            this.AddExerciseBtn.Click += new System.EventHandler(this.AddExerciseBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cancelBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelBtn.Location = new System.Drawing.Point(291, 336);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(124, 50);
            this.cancelBtn.TabIndex = 11;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = false;
            // 
            // AddExerciseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 398);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.AddExerciseBtn);
            this.Controls.Add(this.txtBoxWeight);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBoxReps);
            this.Controls.Add(this.txtBoxSets);
            this.Controls.Add(this.txtBoxExerciseName);
            this.Controls.Add(this.txtBoxExerciseType);
            this.Name = "AddExerciseForm";
            this.Text = "AddExerciseForm";
            this.Load += new System.EventHandler(this.AddExerciseForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxExerciseType;
        private System.Windows.Forms.TextBox txtBoxExerciseName;
        private System.Windows.Forms.TextBox txtBoxSets;
        private System.Windows.Forms.TextBox txtBoxReps;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBoxWeight;
        private System.Windows.Forms.Button AddExerciseBtn;
        private System.Windows.Forms.Button cancelBtn;
    }
}