﻿namespace FitnessApplication
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnFitness = new System.Windows.Forms.Button();
            this.NutritionBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnFitness
            // 
            this.BtnFitness.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFitness.Location = new System.Drawing.Point(139, 295);
            this.BtnFitness.Name = "BtnFitness";
            this.BtnFitness.Size = new System.Drawing.Size(190, 63);
            this.BtnFitness.TabIndex = 3;
            this.BtnFitness.Text = "Fitness";
            this.BtnFitness.UseVisualStyleBackColor = true;
            this.BtnFitness.Click += new System.EventHandler(this.BtnFitness_Click);
            // 
            // NutritionBtn
            // 
            this.NutritionBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NutritionBtn.Location = new System.Drawing.Point(139, 197);
            this.NutritionBtn.Name = "NutritionBtn";
            this.NutritionBtn.Size = new System.Drawing.Size(190, 63);
            this.NutritionBtn.TabIndex = 4;
            this.NutritionBtn.Text = "Nutrition";
            this.NutritionBtn.UseVisualStyleBackColor = true;
            this.NutritionBtn.Click += new System.EventHandler(this.NutritionBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(100, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 46);
            this.label1.TabIndex = 5;
            this.label1.Text = "Landing Page";
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 419);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NutritionBtn);
            this.Controls.Add(this.BtnFitness);
            this.Name = "MainMenu";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnFitness;
        private System.Windows.Forms.Button NutritionBtn;
        private System.Windows.Forms.Label label1;
    }
}

